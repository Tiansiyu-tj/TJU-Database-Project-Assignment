import os
import pickle

import pandas as pd
from tqdm import tqdm

from config import CSV_FILES, CHUNK_SIZE, INOUT_RESUME_FILE
from db import get_connection, batch_insert, truncate_table, commit, commit_and_close
from utils import parse_time


def load_inout_and_timeSegment() -> set:
    """
    将进出站流量 CSV 导入数据库，同时构建 TimeSegment 表。

    核心逻辑：
    - timeslot 为全局唯一标识，直接用作 TimeSegment.Slot 主键
    - 分块读取大文件（200+ MB），每块处理后立即写入数据库
    - 保证外键依赖：每块先插入新增 TimeSegment，再插入对应流量
    - 内存控制：每块结束后清空临时列表，避免累积
    - 去重机制：全局 seen_slots 防止重复插入 TimeSegment

    Returns:
            seen_slots (set): 已处理的全局唯一 timeslot 集合，用于 OD 流量模块去重插入 TimeSegment
    """
    conn = get_connection()

    # ---------- 断点续传加载 ----------
    start_row = 0  # 如果从断点恢复，需要跳过的行数
    seen_slots = set()  # 全局去重：记录已插入的 timeslot
    if os.path.exists(INOUT_RESUME_FILE):
        with open(INOUT_RESUME_FILE, 'rb') as f:
            resume_data = pickle.load(f)
            seen_slots = resume_data['seen_slots']  # 从断点恢复
            start_row = resume_data['processed_rows']
        print(f"[断点恢复] 已处理 {start_row} 行，恢复 {len(seen_slots)} 个时段")

    if start_row == 0:
        truncate_table(conn, 'TimeSegment')
        truncate_table(conn, 'Inflow')
        truncate_table(conn, 'Outflow')

    # 分块读取进出站流量 CSV
    chunk_iter = pd.read_csv(
        CSV_FILES['InOutFlow'],
        skipinitialspace=True,  # 忽略逗号后的空格
        chunksize=CHUNK_SIZE,
        skiprows=range(1, start_row + 1) if start_row > 0 else None,
        dtype={
            'date'   : str, 'timeslot': int, 'startTime': str, 'endTime': str,
            'station': int,
            'inFlow' : int, 'CinFlow': int, 'HBOinFlow': int, 'NHBinFlow': int,
            'outFlow': int, 'CoutFlow': int, 'HBOoutFlow': int, 'NHBoutFlow': int
        }
    )

    # 块临时存储区
    timeSegment_rows = []  # 块新增 TimeSegment 记录
    inflow_rows = []  # 块进站流量
    outflow_rows = []  # 块出站流量

    processed_in_run = 0

    # 逐块处理 CSV 数据
    for chunk in tqdm(chunk_iter, desc="导入InOutFlow"):
        # 清空本块临时数据（防止上块残留）
        timeSegment_rows.clear()
        inflow_rows.clear()
        outflow_rows.clear()

        # 统一处理日期与时间字段
        chunk['date'] = chunk['date'].str.strip()
        chunk['recordDate'] = pd.to_datetime(chunk['date'], format='%Y%m%d').dt.strftime('%Y-%m-%d')
        chunk['startTime'] = chunk['startTime'].astype(str).apply(parse_time)
        chunk['endTime'] = chunk['endTime'].astype(str).apply(parse_time)

        # 遍历本块每一行
        for _, row in chunk.iterrows():
            slot_id = row['timeslot']

            # 首次出现的新时段 → 加入 TimeSegment
            if slot_id not in seen_slots:
                seen_slots.add(slot_id)
                timeSegment_rows.append({
                    'Slot'      : slot_id,
                    'recordDate': row['recordDate'],
                    'StartTime' : row['startTime'],
                    'EndTime'   : row['endTime']
                })

            # 构造进站记录
            inflow_rows.append({
                'Slot'     : slot_id,
                'stationID': row['station'],
                'Tot_IF'   : row['inFlow'],
                'C_IF'     : row['CinFlow'],
                'HB_IF'    : row['HBOinFlow'],
                'NHB_IF'   : row['NHBinFlow']
            })
            # 构造出站记录
            outflow_rows.append({
                'Slot'     : slot_id,
                'stationID': row['station'],
                'Tot_OF'   : row['outFlow'],
                'C_OF'     : row['CoutFlow'],
                'HB_OF'    : row['HBOoutFlow'],
                'NHB_OF'   : row['NHBoutFlow']
            })

        # 先写入本块新增的 TimeSegment（满足外键依赖）
        if timeSegment_rows:
            batch_insert(conn, table_name='TimeSegment', data_list=timeSegment_rows)

        # 再写入本块的进出站流量
        batch_insert(conn, table_name='Inflow', data_list=inflow_rows)
        batch_insert(conn, table_name='Outflow', data_list=outflow_rows)

        processed_in_run += len(chunk)

        commit(conn)
        # ---------- 持久化断点 ----------
        resume_data = {
            'seen_slots'    : seen_slots,
            'processed_rows': start_row + processed_in_run
        }
        os.makedirs(os.path.dirname(INOUT_RESUME_FILE), exist_ok=True)
        with open(INOUT_RESUME_FILE, 'wb') as f:
            pickle.dump(resume_data, f)

    # 成功完成 → 删除断点文件
    if os.path.exists(INOUT_RESUME_FILE):
        os.remove(INOUT_RESUME_FILE)
        print(f"[导入完成] 断点文件已删除：{INOUT_RESUME_FILE}")

    commit_and_close(conn)
    return seen_slots
