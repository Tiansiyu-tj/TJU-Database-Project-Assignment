import os
import tempfile

import pandas as pd
from sqlalchemy import create_engine, text

from config import DB_CONFIG, TRUNCATE_TABLES

# 创建数据库引擎（打开 local_infile）
engine = create_engine(
    f"mysql+pymysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@"
    f"{DB_CONFIG['host']}/{DB_CONFIG['database']}?charset={DB_CONFIG['charset']}&local_infile=1"
)


def get_connection():
    """获取数据库连接 + 关闭检查 + 开启事务"""
    conn = engine.connect()

    # ===== 关键优化：关闭检查 + 关闭自动提交 =====
    conn.execute(text("SET FOREIGN_KEY_CHECKS=0;"))
    conn.execute(text("SET UNIQUE_CHECKS=0;"))
    conn.execute(text("SET AUTOCOMMIT=0;"))
    # conn.execute(text("SET SESSION innodb_lock_wait_timeout = 120;"))
    # conn.execute(text("SET SESSION innodb_flush_log_at_trx_commit=2;"))
    return conn

def commit(conn):
    """提交事务"""
    try:
        conn.execute(text("COMMIT;"))
    except:
        conn.execute(text("ROLLBACK;"))
        raise

def commit_and_close(conn):
    """统一提交 + 恢复设置 + 关闭连接"""
    try:
        conn.execute(text("COMMIT;"))
    except:
        conn.execute(text("ROLLBACK;"))
        raise
    finally:
        # 恢复默认设置
        conn.execute(text("SET FOREIGN_KEY_CHECKS=1;"))
        conn.execute(text("SET UNIQUE_CHECKS=1;"))
        conn.execute(text("SET AUTOCOMMIT=1;"))
        # conn.execute(text("SET SESSION innodb_flush_log_at_trx_commit=1;"))
        conn.close()


def batch_insert(conn, table_name: str, data_list: "list[dict]") -> None:
    """批量插入（使用 LOAD DATA INFILE 提升性能）"""
    if not data_list:
        return

    df = pd.DataFrame(data_list)

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', encoding='utf8', newline='') as f:
        temp_path = f.name
        df.to_csv(f, index=False, header=True, na_rep='\\N', sep=',')

    try:
        columns = df.columns.tolist()
        cols_str = ", ".join([f"`{c}`" for c in columns])

        sql = f"""
            LOAD DATA LOCAL INFILE '{temp_path.replace(os.sep, '/')}'
            INTO TABLE `{table_name}`
            FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\\n'
            IGNORE 1 LINES
            ({cols_str})
        """
        # print(f"LOAD DATA → {table_name} ({len(df)} 行)")
        conn.execute(text(sql))
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def truncate_table(conn, table_name):
    """清空表（保持不变）"""
    if TRUNCATE_TABLES:
        conn.execute(f"TRUNCATE TABLE {table_name}")
