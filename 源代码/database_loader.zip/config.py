import os

# 数据目录
BASE_DIR = "./data/MetroFlow"
METRO_DATA = os.path.join(BASE_DIR, "MetaData")

# 数据库连接配置
DB_CONFIG = {
    'user'    : 'metro_admin',
    'password': '123456',
    'host'    : 'localhost',  # 本地数据库
    'database': 'shanghai_metro',
    'charset' : 'utf8mb4'
}

# 断点续传文件路径
CACHE_DIR = "cache"
INOUT_RESUME_FILE = os.path.join(CACHE_DIR, 'inout_resume.pkl')
OD_RESUME_FILE = os.path.join(CACHE_DIR, 'od_resume.pkl')

# CSV 文件路径
CSV_FILES = {
    'station'  : os.path.join(BASE_DIR, 'stationInfo.csv'),
    'InOutFlow': os.path.join(BASE_DIR, 'metroData_InOutFlow.csv'),
    'ODFlow'   : os.path.join(BASE_DIR, 'metroData_ODFlow.csv'),
    'weather'  : os.path.join(METRO_DATA, 'shanghai_weatherHourly.csv'),
    'workday'  : os.path.join(METRO_DATA, 'workday_calendar.csv')
}

CHUNK_SIZE = 50000  # 分块大小（平衡内存与速度）
TRUNCATE_TABLES = False  # 是否清空表（谨慎！）
