from DateLoader import load_date_info
from InOutLoader import load_inout_and_timeSegment
from ODLoader import load_ODFlow
from StationLoader import load_stations


def main(is_stations=True, is_date_info=True, is_inout_and_timeSegment=True, is_ODFlow=True):
    """主函数，按需加载数据"""
    print("=== 上海地铁数据导入系统 ===")

    if is_stations:
        load_stations()  # 站点
    if is_date_info:
        load_date_info()  # 日期信息

    seen_slots = set()
    if is_inout_and_timeSegment:
        seen_slots = load_inout_and_timeSegment()  # 进出站 + Slot → 返回 seen_slots
    if is_ODFlow:
        load_ODFlow(seen_slots)  # OD 流量（大文件）

    print("所有数据导入完成！")


if __name__ == "__main__":
    main(
        is_stations=False,
        is_date_info=False,
        is_inout_and_timeSegment=False,
        is_ODFlow=True
    )
