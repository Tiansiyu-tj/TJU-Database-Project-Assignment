import os
import pickle

import pandas as pd
from tqdm import tqdm

from config import CSV_FILES, CHUNK_SIZE, OD_RESUME_FILE
from db import get_connection, batch_insert, commit, commit_and_close
from utils import parse_time


def load_ODFlow(seen_slots: set):
    """
    分块导入 11.2GB OD 流量，动态补充 TimeSegment（Slot = timeslot，全局唯一）

    核心逻辑：
    - 接收来自进出站模块的 seen_slots（已存在的 timeslot）
    - 若 OD 中出现新 timeslot → 直接插入 TimeSegment（去重）
    - 每块立即插入 ODFlow，内存安全
    - 不使用自增 ID，直接用 timeslot 作为 Slot
    - 断点续传：基于 processed_rows + skiprows + pickle 持久化
    """
    conn = get_connection()

    # ---------- 断点续传加载 ----------
    start_row = 0
    if os.path.exists(OD_RESUME_FILE):
        with open(OD_RESUME_FILE, 'rb') as f:
            resume_data = pickle.load(f)
            seen_slots.update(resume_data['seen_slots'])
            start_row = resume_data['processed_rows']
        print(f"[OD 断点恢复] 已处理 {start_row} 行，恢复 {len(resume_data['seen_slots'])} 个时段")

    # 先获取列名（读 header）
    header_df = pd.read_csv(CSV_FILES['ODFlow'], nrows=0, skipinitialspace=True)
    columns = header_df.columns.tolist()

    # 分块读数据：跳过 header(1行) + 已处理的 start_row 行
    chunk_iter = pd.read_csv(
        CSV_FILES['ODFlow'],
        chunksize=CHUNK_SIZE,
        skipinitialspace=True,
        skiprows=1 + start_row,  # 跳过第0行(header) + 第1~start_row行(数据)
        header=None,  # 不再自动读 header
        names=columns,  # 手动指定列名
        dtype={
            'date'         : str, 'timeslot': int, 'startTime': str, 'endTime': str,
            'originStation': int, 'destinationStation': int,
            'Flow'         : int, 'CFlow': int, 'HBOFlow': int, 'NHBFlow': int
        }
    )

    ODFlow_rows = []
    timeSegment_rows = []
    processed_in_run = 0

    for chunk in tqdm(chunk_iter, desc="ODFlow 分块"):
        # 清空本块临时数据
        timeSegment_rows.clear()
        ODFlow_rows.clear()

        # 统一处理日期与时间
        chunk['date'] = chunk['date'].astype(str).str.strip()
        chunk['recordDate'] = pd.to_datetime(chunk['date'], format='%Y%m%d').dt.strftime('%Y-%m-%d')
        chunk['startTime'] = chunk['startTime'].astype(str).apply(parse_time)
        chunk['endTime'] = chunk['endTime'].astype(str).apply(parse_time)

        new_slots_mask = ~chunk['timeslot'].isin(seen_slots)  # 找出所有 timeslot 是新出现的行
        new_time_segments = chunk[new_slots_mask].drop_duplicates(subset=['timeslot'])  # 筛选出新 Slot 的行，并去重
        # 提取新 Slot 的数据并更新 seen_slots
        if not new_time_segments.empty:
            seen_slots.update(new_time_segments['timeslot'])  # 更新全局 seen_slots 集合

            # 构造 TimeSegment 的 DataFrame，准备批量插入
            timeSegment_df = new_time_segments[[
                'timeslot', 'recordDate', 'startTime', 'endTime'
            ]].rename(columns={
                'timeslot' : 'Slot',
                'startTime': 'StartTime',
                'endTime'  : 'EndTime'
            })

            # 转换为 list[dict]
            timeSegment_rows = timeSegment_df.to_dict('records')

        # 构造 ODFlow DataFrame，避免循环
        ODFlow_df = chunk[[
            'timeslot', 'originStation', 'destinationStation',
            'Flow', 'CFlow', 'HBOFlow', 'NHBFlow'
        ]].rename(columns={
            'timeslot'          : 'Slot',
            'originStation'     : 'O_Station',
            'destinationStation': 'D_Station',
            'Flow'              : 'Tot_F',
            'CFlow'             : 'C_F',
            'HBOFlow'           : 'HB_F',
            'NHBFlow'           : 'NHB_F'
        })

        # 转换为 list[dict]
        ODFlow_rows = ODFlow_df.to_dict('records')

        # 先插入本块新 TimeSegment（外键安全）
        if timeSegment_rows:
            batch_insert(conn, table_name='TimeSegment', data_list=timeSegment_rows)

        # 再插入本块 OD 流量
        batch_insert(conn, table_name='ODFlow', data_list=ODFlow_rows)
        processed_in_run += len(chunk)

        commit(conn)
        # ---------- 持久化断点 ----------
        resume_data = {
            'seen_slots'    : seen_slots,
            'processed_rows': start_row + processed_in_run
        }
        os.makedirs(os.path.dirname(OD_RESUME_FILE), exist_ok=True)
        with open(OD_RESUME_FILE, 'wb') as f:
            pickle.dump(resume_data, f)

    # 成功完成 → 删除断点文件
    if os.path.exists(OD_RESUME_FILE):
        os.remove(OD_RESUME_FILE)
        print(f"ODFlow成功导入{start_row + processed_in_run}条数据")
        print(f"[OD 导入完成] 断点文件已删除：{OD_RESUME_FILE}")

    commit_and_close(conn)
