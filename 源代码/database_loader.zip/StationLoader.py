import pandas as pd
from tqdm import tqdm

from config import CSV_FILES
from db import get_connection, batch_insert, truncate_table, commit_and_close
from utils import safe_json_load


def load_stations():
    """
    将站点信息 CSV 导入数据库，同时构建 Station 和 Neighbour 表。

    核心逻辑：
    - 读取包含站点基本信息与邻站 JSON 列表的 CSV
    - 批量插入 Station 表（站点 ID、名称、经纬度）
    - 解析 neighbour 字段（JSON 数组），展开为多条邻站关系
    - 批量插入 Neighbour 表（stationID → neighbourID）
    - 使用 safe_json_load 防止 JSON 解析异常
    """
    conn = get_connection()
    truncate_table(conn, 'Station')
    truncate_table(conn, 'Neighbour')

    # 读取站点 CSV，统一列名
    df = pd.read_csv(CSV_FILES['station'])
    df = df.iloc[:, 1:6]
    df.columns = ['stationID', 'name', 'lon', 'lat', 'neighbour']

    # 插入 Station 表：站点基础信息
    station_data = df[['stationID', 'name', 'lon', 'lat']].to_dict('records')
    batch_insert(conn, table_name='Station', data_list=station_data)
    print(f"已插入 {len(station_data)} 条站点记录到 Station 表。")

    # 解析 neighbour JSON 数组，生成邻站关系记录
    neighbour_rows = []
    for _, row in tqdm(df.iterrows(), total=len(df), desc="解析邻站"):
        sid = row['stationID']
        for nid in safe_json_load(row['neighbour']):
            neighbour_rows.append({'stationID': sid, 'neighbourID': nid})

    # 插入 Neighbour 表：邻站关系
    batch_insert(conn, table_name='Neighbour', data_list=neighbour_rows)
    print(f"已插入 {len(neighbour_rows)} 条邻站关系到 Neighbour 表。")

    # 关闭连接
    commit_and_close(conn)