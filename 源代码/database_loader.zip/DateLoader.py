import time

import pandas as pd

from config import CSV_FILES
from db import get_connection, batch_insert, truncate_table, commit_and_close


def load_date_info() -> None:
    """
    1. 把 workday_calendar.csv → DateInfo（每日工作日）
    2. 把 shanghai_weatherHourly.csv → Weather（每小时天气）

    备注：
    - 必须先插入 DateInfo，再插入 Weather（外键依赖）
    """
    print("正在导入 DateInfo（工作日） + Weather（每小时天气）...")
    conn = get_connection()

    # ====================== 1. DateInfo（工作日） ======================
    truncate_table(conn, 'DateInfo')

    ''' 
        CSV: workday_calendar.csv
        原始格式: date    , isWorkday
                 20170501,  0
    '''
    workday_df = pd.read_csv(CSV_FILES['workday'], skipinitialspace=True)  # 读取工作日数据
    workday_df['date'] = workday_df['date'].astype(str).str.strip()  # 清理日期字符串
    workday_df['recordDate'] = pd.to_datetime(workday_df['date'], format='%Y%m%d').dt.strftime('%Y-%m-%d')

    dateInfo_rows = workday_df[['recordDate', 'isWorkday']].to_dict('records')

    batch_insert(conn, table_name='DateInfo', data_list=dateInfo_rows)
    print(f"DateInfo 导入完成：{len(dateInfo_rows)} 天")

    # ====================== 2. Weather（每小时） =====================
    truncate_table(conn, 'Weather')

    '''
        CSV: shanghai_weatherHourly.csv
        原始格式: date             , temperature_2m, apparent_temperature, rain, wind_speed_10m
                 20170501 00:00:00, 16.793499     , 15.912954         , 0.0 , 12.313893
    '''
    weather_df = pd.read_csv(CSV_FILES['weather'], skipinitialspace=True)  # 读取天气数据

    # 解析完整时间戳 → DATE + TIME
    weather_df['datetime'] = pd.to_datetime(weather_df['date'], format='%Y%m%d %H:%M:%S')
    weather_df['recordDate'] = weather_df['datetime'].dt.date
    weather_df['recordTime'] = weather_df['datetime'].dt.time.astype(str)  # MySQL TIME 需要 'HH:MM:SS'

    weather_rows = []
    for _, row in weather_df.iterrows():
        weather_rows.append({
            'recordDate'          : row['recordDate'],
            'recordTime'          : row['recordTime'],
            'temperature_2m'      : round(row['temperature_2m'], 6),
            'apparent_temperature': round(row['apparent_temperature'], 6),
            'rain'                : round(row['rain'], 1),
            'wind_speed_10m'      : round(row['wind_speed_10m'], 6)
        })

    batch_insert(conn, table_name='Weather', data_list=weather_rows)
    print(f"Weather 导入完成：{len(weather_rows)} 条记录")

    commit_and_close(conn)
