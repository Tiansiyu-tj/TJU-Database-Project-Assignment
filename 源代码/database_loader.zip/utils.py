import json


def parse_time(t):
    """061000 → 06:10:00"""
    t = str(t).strip().zfill(6)
    return f"{t[:2]}:{t[2:4]}:{t[4:6]}"


def safe_json_load(s):
    """安全解析 neighbour 字段（如 "[312, 314]"）"""
    try:
        return json.loads(s.replace("'", '"'))
    except:
        return []  # 解析失败返回空列表
